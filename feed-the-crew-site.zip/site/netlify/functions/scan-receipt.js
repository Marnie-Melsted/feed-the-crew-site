// Runs the AI receipt scanner server-side, so the Anthropic API key never
// reaches the browser. Only works for a token signed with plan:"pro".
const { verifyToken } = require('./_auth');

exports.handler = async (event) => {
  let body;
  try {
    body = JSON.parse(event.body || "{}");
  } catch (e) {
    return { statusCode: 400, body: JSON.stringify({ error: "Bad request." }) };
  }

  const access = body.token ? verifyToken(body.token, process.env.ACCESS_TOKEN_SECRET) : null;
  if (!access || access.plan !== "pro") {
    return { statusCode: 403, body: JSON.stringify({ error: "This feature requires a Pro & Catering plan." }) };
  }

  const prompt = `This image is a grocery receipt or supplier invoice. List every purchased line item you can read clearly, with the total price paid and the quantity/unit if shown. Respond with ONLY a JSON array, no other text, no markdown fences: [{"item":"item name as written","totalPaid":12.99,"quantity":1,"unit":"kg"}]. If quantity or unit isn't shown, use quantity:1 and unit:"each". Use unit values from this set when possible: kg, L, each, slices.`;

  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": process.env.ANTHROPIC_API_KEY,
      "anthropic-version": "2023-06-01"
    },
    body: JSON.stringify({
      model: "claude-sonnet-4-6",
      max_tokens: 1000,
      messages: [{
        role: "user",
        content: [
          { type: "image", source: { type: "base64", media_type: body.mediaType, data: body.base64Image } },
          { type: "text", text: prompt }
        ]
      }]
    })
  });

  if (!response.ok) {
    return { statusCode: 502, body: JSON.stringify({ error: "AI service error (" + response.status + ")" }) };
  }
  const data = await response.json();
  return { statusCode: 200, headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) };
};
