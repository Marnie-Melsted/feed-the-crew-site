// Called each time app.html loads, to check a token already stored in the browser
// is still validly signed and not expired. No Stripe call needed for this check —
// it's just verifying our own signature.
const { verifyToken } = require('./_auth');

exports.handler = async (event) => {
  let token;
  try {
    token = JSON.parse(event.body || "{}").token;
  } catch (e) {
    token = null;
  }

  const result = token ? verifyToken(token, process.env.ACCESS_TOKEN_SECRET) : null;

  return {
    statusCode: 200,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(result ? { valid: true, plan: result.plan } : { valid: false })
  };
};
