// Called right after Stripe redirects a customer back to app.html?session_id=...
// Confirms the payment really happened (server-side, can't be faked from the browser)
// and mints a signed access token identifying which plan they bought.
const { signToken } = require('./_auth');

exports.handler = async (event) => {
  const sessionId = event.queryStringParameters && event.queryStringParameters.session_id;
  if (!sessionId) {
    return { statusCode: 400, body: JSON.stringify({ error: "Missing session_id" }) };
  }

  const stripeKey = process.env.STRIPE_SECRET_KEY;
  const resp = await fetch(
    `https://api.stripe.com/v1/checkout/sessions/${sessionId}?expand[]=line_items`,
    { headers: { "Authorization": "Basic " + Buffer.from(stripeKey + ":").toString("base64") } }
  );

  if (!resp.ok) {
    return { statusCode: 400, body: JSON.stringify({ error: "Could not verify this payment with Stripe." }) };
  }

  const session = await resp.json();
  if (session.payment_status !== "paid" && session.status !== "complete") {
    return { statusCode: 400, body: JSON.stringify({ error: "Payment not completed." }) };
  }

  // Match the Stripe Price ID to figure out which of your two plans was bought.
  // Set STRIPE_PRICE_ID_PRO in Netlify's environment variables to your actual Pro price ID.
  const priceId = session.line_items && session.line_items.data[0] && session.line_items.data[0].price.id;
  const plan = priceId === process.env.STRIPE_PRICE_ID_PRO ? "pro" : "home";

  const token = signToken(plan, session.customer_email, process.env.ACCESS_TOKEN_SECRET);

  return {
    statusCode: 200,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ token, plan })
  };
};
