// Runs the AI nutrition estimator server-side. Only works for a token
// signed with plan:"pro".
const { verifyToken } = require('./_auth');

exports.handler = async (event) => {
  let body;
  try {
    body = JSON.parse(event.body || "{}");
  } catch (e) {
    return { statusCode: 400, body: JSON.stringify({ error: "Bad request." }) };
  }

  const access = body.token ? verifyToken(body.token, process.env.ACCESS_TOKEN_SECRET) : null;
  if (!access || access.plan !== "pro") {
    return { statusCode: 403, body: JSON.stringify({ error: "This feature requires a Pro & Catering plan." }) };
  }

  const prompt = `Estimate the calories and protein (in grams) for one serving of this recipe: "${body.recipeName || 'recipe'}", serving size ${body.servingDescription || '1 serving'}. Ingredients for the whole recipe: ${body.ingredientList}. Respond with ONLY JSON, no other text, no markdown fences: {"calories":650,"protein":35}.`;

  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": process.env.ANTHROPIC_API_KEY,
      "anthropic-version": "2023-06-01"
    },
    body: JSON.stringify({
      model: "claude-sonnet-4-6",
      max_tokens: 300,
      messages: [{ role: "user", content: prompt }]
    })
  });

  if (!response.ok) {
    return { statusCode: 502, body: JSON.stringify({ error: "AI service error (" + response.status + ")" }) };
  }
  const data = await response.json();
  return { statusCode: 200, headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) };
};
