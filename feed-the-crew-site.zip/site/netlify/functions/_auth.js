// Shared helper: signs and verifies lightweight access tokens.
// Not a full accounts system — see SETUP.md for what this does and doesn't cover.
const crypto = require('crypto');

function signToken(plan, email, secret, ttlDays = 35) {
  const expires = Date.now() + ttlDays * 24 * 60 * 60 * 1000;
  const payload = `${plan}.${expires}.${email || ""}`;
  const signature = crypto.createHmac("sha256", secret).update(payload).digest("hex");
  return Buffer.from(`${payload}.${signature}`).toString("base64");
}

function verifyToken(token, secret) {
  try {
    const decoded = Buffer.from(token, "base64").toString("utf8");
    const parts = decoded.split(".");
    const signature = parts.pop();
    const payload = parts.join(".");
    const expected = crypto.createHmac("sha256", secret).update(payload).digest("hex");
    if (signature !== expected) return null;
    const [plan, expires] = payload.split(".");
    if (Date.now() > Number(expires)) return null;
    return { plan, expires: Number(expires) };
  } catch (e) {
    return null;
  }
}

module.exports = { signToken, verifyToken };
